
#include <bits/stdc++.h>

using namespace std;

struct Node {
    int val;
    Node *left, *right;
    Node(int x) : val(x), left(NULL), right(NULL) {}
};

vector<vector<int>> ans;

void trav(Node* root){
    
    // This line is always important. We can have a testcase where the root
    // points is NULL i.e. we have no tree itself
    // In such cases, we cannot perform any operation of a tree (as we have no tree)
    // So we must always return else we will get RUNTIME error
    if(root == NULL) return;
    
    // Here, we must keep <pair<Node*,int>> as we have no idea of the depth of the tree
    // In normal BFS, we use dis to keep track of the level, here we have no such dis array
    // So must use our own level indicated by int in pair.second
    queue<pair<Node*,int>> q;
    q.push({root,0});

    while(!q.empty()){
        auto node = q.front();q.pop();
        ans.push_back({});
        ans[node.second].push_back(node.first->val);

        if(node.first->left!=NULL){
            q.push({node.first->left,node.second+1});
        }
        if(node.first->right!=NULL){
            q.push({node.first->right,node.second+1});
        }

    }
}

vector<vector<int>> getLevelorderTraversal(Node* root) {
  ans.clear();
  trav(root);
  return ans;
}


Node* getBinaryTree(vector<int> &num, int*ind) {
    if(num[*ind] == -1)
        return NULL;
    Node* node = new Node(num[*ind]);
    (*ind)++;
    node->left = getBinaryTree(num,ind);
    (*ind)++;
    node->right = getBinaryTree(num,ind);
    return node;
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0); cout.tie(0);

#ifndef ONLINE_JUDGE
    freopen("Input.txt","r",stdin);
    freopen("Output.txt","w",stdout);
    freopen("Error.txt","w",stderr);
    clock_t tStart = clock();
    cout<<fixed<<setprecision(10)<<"Time Taken: "<<(double)(clock()- tStart)/CLOCKS_PER_SEC<<endl;
#endif

    int t;
    cin >> t;
    while(t--){
        int n;
        cin>>n;
        assert(n<=1000000);
        vector<int>arr(n);
        for(int i=0;i<n;i++)
            cin>>arr[i];
        int ind = 0;
        Node* tree = getBinaryTree(arr,&ind);
        vector<vector<int>> ans = getLevelorderTraversal(tree);
        int i = 1;
        for(auto u:ans){
            cout << i << " : ";
            for(auto v:u){
                cout<<v<<" ";
            }
            cout<<"\n";
            i++;
        }
        cout<<"\n";
    }
    return 0;
}
