# Jun 30 Goals

1. [] Complete codes of DP Form 4
	[•] - Rod Cutting Problem
	[•]  - Palindrome Partitioning
	[•]  - Merge Elements
2. [] Complete the Problem Sheets
	[]  - Jun 29 Ka Leetcode Daily
	[]  - Add DP Form 4 Codes
	[]  - Add DP Form 3 Codes
3. [] Implement DIFF UTILITY - DP Form 3

4. [] DP Form 2 Questions: 
	[]  - The Witcher 2
	[]  - Count LIS

---

# LEGEND
[ ] - No progress.
[x] - Currently doing it
[•] - Done
