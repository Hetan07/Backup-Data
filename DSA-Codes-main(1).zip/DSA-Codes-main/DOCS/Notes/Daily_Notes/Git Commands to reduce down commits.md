git reset --soft HEAD~n
git add .
git commmit -m "Message"
git push -f
git commit --amend

We don't force push in the main branch, but in our own working branches it is fine to force push

![[Pasted image 20240726150458.png]]

![[Pasted image 20240726150600.png]]ss
