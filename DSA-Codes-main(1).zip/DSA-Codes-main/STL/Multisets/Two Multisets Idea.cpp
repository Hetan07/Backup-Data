#include<bits/stdc++.h>
using namespace std; 


using pii = pair<int,int>;
class Solution {
public:
    int findMaximizedCapital(int k, int w, vector<int>& p, vector<int>& c) {
    int n = c.size();

    multiset<pii> take;
    multiset<pii> avail;


    // Just insertion into the two multisets
    for(int i = 0; i < n;i++){
        if(c[i]<=w){
            take.insert({p[i],c[i]});
        }else{
            avail.insert({c[i],p[i]});
        }
    }

    while(k>0 && !take.empty()){
        auto it = take.rbegin(); // reverse iterator
        w+=it->first;
        
        auto del = make_pair(it->first,it->second); 
        // This is required as erase cannot take reverse_it
        // But as multiset erase can delete by value, we copy the value
        
        
        // More correct implementation of erase is:
        /*
            auto it = mt.find(val);
            if(it!=it.end()){
                mt.erase(it); -> Always remove one element
            }
        */

        take.erase(take.find(del)); // This also works but can give undefined behaviour
        // if the element value is not present

        // Rebalancing Idea: Just like Mean,Median,Mode
        // Elements go to the take based on some constraint


        // Iterator logic with the template
        for(auto it = avail.begin(); it!=avail.end();){
            if(it->first<=w){
                auto ins = make_pair(it->second,it->first);
                take.insert(ins);
                it = avail.erase(it); // Favoured implementation
                // Note, avail.erase(it++) will also work

            }else{
                it++;// OR ++it;
            }
        }
        k--;
    }
    return w;
    }
};