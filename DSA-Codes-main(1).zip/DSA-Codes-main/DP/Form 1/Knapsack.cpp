#include<bits/stdc++.h>
using namespace std;

// Simple Debugging Template
#ifndef ONLINE_JUDGE
#define pr_arr(a,n)cout<<#a<<":";for(int i=0;i<n;i++)cout<<a[i]<<" ";cout<<endl;
#define pr_mat(mat,row,col)cout<<#mat<<":\n";for(int i=0;i<row;i++){for(int j=0;j<col;j++)cout<<mat[i][j]<<" ";cout<<endl;}
#define pr(...)dbs(#__VA_ARGS__,__VA_ARGS__)
template<class S,class T>ostream &operator<<(ostream &os,const pair<S,T> &p){return os<<"("<<p.first<<","<<p.second<<")";}
template<class T>ostream &operator<<(ostream &os,const vector<T> &p){os<<"[";for(auto&it:p)os<<it<<" ";return os<<"]";}
template<class T>ostream &operator<<(ostream &os,const set<T>&p){os<<"[";for(auto&it:p)os<<it<<" ";return os<<"]";}
template<class T>ostream &operator<<(ostream &os, const stack<T>&s){os<<"[";stack<T> temp(s);while (!temp.empty()){os << temp.top();temp.pop();if (!temp.empty())os << ", ";}return os << "]";}
template<class T>ostream &operator<<(ostream &os, const queue<T>&q){os<<"[";queue<T>temp(q);int size=temp.size();for(int i=0;i<size;i++){T front=temp.front();os<<front;temp.pop();if(i<size-1)os<< ", ";temp.push(front);}return os<< "]";}
template<class T>ostream &operator<<(ostream &os,const multiset<T>&p){os<<"[";for(auto&it:p)os<<it<<" ";return os<<"]";}
template<class T> ostream &operator<<(ostream &os, const priority_queue<T>&pq){os<<"[";priority_queue<T> temp(pq);while(!temp.empty()){os<<temp.top();temp.pop();if(!temp.empty()){os<<", ";}}return os << "]";}
template<class S,class T>ostream &operator<<(ostream &os,const map<S,T>&p){os<<"[";for(auto&it:p)os<<it<<" ";return os<<"]";}
template<class T>void dbs(string str,T t){cout<<str<<":"<<t<<"\n";}
template<class T,class...S>void dbs(string str,T t,S... s){int idx=str.find(',');cout<<str.substr(0,idx)<<":"<<t<<",";dbs(str.substr(idx+1),s...);}
template<class T>ostream &operator<<(ostream &os, const deque<T>&d){os<<"[";for(auto&it:d) os << it << " ";return os<<"]";}
#endif
// Debugging Template ends
#define f                       first
#define s                       second
#define ARRAY_INPUT(arr, n)     for(int i = 0; i < n; i++) cin >> arr[i]
#define FORM(i, j, k, inc)       for(int i=j ; i<k ; i+=inc)
#define FOR(i,x)                for(int i = 0; i < x;i++)
#define mip(x)                  ll x;cin>>x
#define ip(x)                   cin>>x
#define pb                      push_back

using ll = long long;
using pii = pair<int,int>;
using pll = pair<ll,ll>;

using vi = vector<int>;
using vll = vector<long long>;
using vpii = vector<pii>;
using vpll = vector<pll>;

using vvi = vector<vector<int>>;
using vvll = vector<vector<long long>>;
using vvpii = vector<vector<pii>>;
using vvpll = vector<vector<pll>>;

using state = pll;

/*
    @author: Hetanshu Malik : 12 June 2024
    0/1 Knapsack

    Step-1: Form Deciding: This is Form 1 

    Step-2: State Space Formulation 
    
    int rec(int level, int x)
    
    Function Meaning: 
    I'm at choice level `level`, I need to find out the maximum
    profit/value I can get from [lvl .. N] provided that I have 
    decided/chosen my options from [0 .. lvl-1] 

    Step-3: Transition
    rec(i,x) -> Take is: v[i] + rec(i+1,x-w[i])
             -> Not Take is: rec(i+1,x);

    Step-4: TL Check 
        #s -> N*W -> 9 * 1e6
        1+#t -> 1+2 -> 3
        TC (3* N*W)
*/

int n,W;
int w[3003];
int v[3003];

int dp[3003][3003];
//  dp[N][W];



int rec(int level, int x){

    // pruning

    // basecase -> depends on our function meaning
    if(level == n) return 0;
    // We return 0 because due to all the checks we are always in the valid range
    
    // state check
    if(dp[level][x]!=-1) return dp[level][x];

    // transition
    int ans = rec(level+1,x); // Not Take
    if(w[level]<=x) /*This acts like a check of LCCM framework*/{
        ans = max(ans, v[level] + rec(level+1, x-w[level])); // This acts like Move
    }

    // save and return
    dp[level][x] = ans;
    return ans;

}

vi solution;

/*  In generate solution function, we try to emulate the 
    the transition that happens at a stage:
    In essence the transition has to be copied and then using them
    we have to generate the solution.

    One mistake I was doing was using
    int take = rec(level+1,x-w[level]); where I was missing the v[level];

    This means that the transition is not being used properly

    At any level we had the choice of T/NT. Whichever gave the maximum
    meant that we will chose that path

    Here rec() calls will be O(1).

    Using this, if T is present, then that means we have to take that
    index.

*/

void generate(int level, int x){
    if(level == n) return;
    
    else{
        int donttake = rec(level+1,x);
        pr(donttake);
        if(w[level] <= x){
            // Try Take
            int take = v[level]+rec(level+1, x-w[level]);

            pr(take);
            if(donttake > take) generate(level+1,x);
            else{
                pr(level);
                solution.pb(level);
                generate(level+1, x - w[level]);
            }
        }else{
            generate(level+1,x);
        }
    }
}


// For infinite supply or unbounded knapsack
// dp[N][W];
int rec(int level, int x){

    // pruning

    // basecase -> depends on our function meaning
    if(level == n) return 0;
    
    // state check
    if(dp[level][x]!=-1) return dp[level][x];

    // transition
    int ans = rec(level+1,x); // Not Take
    if(w[level]<=x){
        ans = max(ans, v[level] + rec(level, x-w[level]));
        // from ans = max(ans, v[level] + rec(level+1, x-w[level]));
    }
    // This approach of transition to same state leads to transition
    // number of states to still be 2

    // Another way
    /*
    
    for(int num = 1; num <= x/w[level];num++){
        ans = max(ans, num*v[level] + rec(level+1,x-num*w[level]));
    }
    
    Has in worst case transitions upto W -> TC of O(N*W^2)
    */

    // save and return
    dp[level][x] = ans;
    return ans;

}

// Now in 0-1 Knapsack, we can take atmost K items
// We will incorporate this constraint into our state

int dp1[100][100][100];
// int dp [N][W][K];

int rec(int level, int x, int kleft){

    // pruning

    // basecase -> depends on our function meaning
    if(level == n) return 0;
    
    // state check
    if(dp1[level][x][kleft]!=-1) return dp[level][x];

    // transition
    int ans = rec(level+1,x,kleft); // Not Take
    if(w[level]<=x && kleft > 0){
        ans = max(ans, v[level] + rec(level+1, x-w[level], kleft-1));
    }
    
    // save and return
    dp1[level][x][kleft] = ans;
    return ans;
    // TC of O(N*W*K)
}

// Now we need to manage atmost K items and to make sure the sum of the
// items taken is divisble by M

// This can be intelligently dont by using the x. It is the weight 
// left to be taken. Then W - x is the weight taken

int M;
int rec(int level, int x, int kleft){

    // pruning

    // basecase -> depends on our function meaning
    if(level == n){
        int sum = W - x;
        if(sum%M==0){
            // Valid state
            return 0; 
        }else{
            // Invalid state: Return with a huge penalty so that 
            // this is never taken
            return -1e9;
        }
    }
    
    // state check
    if(dp1[level][x][kleft]!=-1) return dp[level][x];

    // transition
    int ans = rec(level+1,x,kleft); // Not Take
    if(w[level]<=x && kleft > 0){
        ans = max(ans, v[level] + rec(level+1, x-w[level], kleft-1));
    }
    
    // save and return
    dp1[level][x][kleft] = ans;
    return ans;
    // TC of O(N*W*K)
}

// The two above constraints and to make sure that if we take
// ith element we do not take i+1th element

// Again this can be managed either in state or transition itself
int taken = 0;
int dp2[100][100][100][2];
int rec(int level, int x, int kleft, int taken){

    // pruning

    // basecase -> depends on our function meaning
    if(level == n){
        int sum = W - x;
        if(sum%M==0){
            // Valid state
            return 0; 
        }else{
            // Invalid state: Return with a huge penalty so that 
            // this is never taken
            return -1e9;
        }
    }
    
    // state check
    if(dp2[level][x][kleft][taken]!=-1) return dp[level][x];

    // transition
    int ans = rec(level+1,x,kleft,0); // Not Take: with ith taken is 0
    if(w[level]<=x && kleft > 0 && !taken) /*This !taken only for state change*/
    {
        ans = max(ans, v[level] + rec(level+2, x-w[level], kleft-1));
        // Here we just move to level+2
    
        // Or if we want to manage in state
        ans = max(ans, v[level] + rec(level+1, x-w[level], kleft-1,1));
    }

    
    // save and return
    dp2[level][x][kleft][taken] = ans;
    return ans;
    // TC of O(N*W*K*2)
}




void solve(){
    cin >> n >> W;
    ARRAY_INPUT(w,n);
    pr_arr(w,n);
    ARRAY_INPUT(v,n);
    pr_arr(v,n);
    memset(dp,-1,sizeof(dp));
    
    // NOTE WHEN CALLING MAKE SURE TO CALL CORRECT REC
    // AS ALL ARE CALLED REC
    pr(rec(0,W));
    generate(0,W);
    pr(solution);
}

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr); cout.tie(nullptr);

#ifndef ONLINE_JUDGE
    freopen("Input.txt","r",stdin);
    freopen("Output.txt","w",stdout);
    freopen("Error.txt","w",stderr);
    clock_t tStart = clock();
    cout<<fixed<<setprecision(10)<<"Time Taken: "<<(double)(clock()- tStart)/CLOCKS_PER_SEC<<endl;
#endif


    int t = 1;
    // cin >> t;
    while(t--){
        solve();
    }
}