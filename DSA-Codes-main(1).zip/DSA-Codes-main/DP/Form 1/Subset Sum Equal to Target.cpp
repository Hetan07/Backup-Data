#include<bits/stdc++.h>
using namespace std;

// Simple Debugging Template
#ifndef ONLINE_JUDGE
#define pr_arr(a,n)cout<<#a<<":";for(int i=0;i<n;i++)cout<<a[i]<<" ";cout<<endl;
#define pr_mat(mat,row,col)cout<<#mat<<":\n";for(int i=0;i<row;i++){for(int j=0;j<col;j++)cout<<mat[i][j]<<" ";cout<<endl;}
#define pr(...)dbs(#__VA_ARGS__,__VA_ARGS__)
template<class S,class T>ostream &operator<<(ostream &os,const pair<S,T> &p){return os<<"("<<p.first<<","<<p.second<<")";}
template<class T>ostream &operator<<(ostream &os,const vector<T> &p){os<<"[";for(auto&it:p)os<<it<<" ";return os<<"]";}
template<class T>ostream &operator<<(ostream &os,const set<T>&p){os<<"[";for(auto&it:p)os<<it<<" ";return os<<"]";}
template<class T>ostream &operator<<(ostream &os, const stack<T>&s){os<<"[";stack<T> temp(s);while (!temp.empty()){os << temp.top();temp.pop();if (!temp.empty())os << ", ";}return os << "]";}
template<class T>ostream &operator<<(ostream &os, const queue<T>&q){os<<"[";queue<T>temp(q);int size=temp.size();for(int i=0;i<size;i++){T front=temp.front();os<<front;temp.pop();if(i<size-1)os<< ", ";temp.push(front);}return os<< "]";}
template<class T>ostream &operator<<(ostream &os,const multiset<T>&p){os<<"[";for(auto&it:p)os<<it<<" ";return os<<"]";}
template<class T> ostream &operator<<(ostream &os, const priority_queue<T>&pq){os<<"[";priority_queue<T> temp(pq);while(!temp.empty()){os<<temp.top();temp.pop();if(!temp.empty()){os<<", ";}}return os << "]";}
template<class S,class T>ostream &operator<<(ostream &os,const map<S,T>&p){os<<"[";for(auto&it:p)os<<it<<" ";return os<<"]";}
template<class T>void dbs(string str,T t){cout<<str<<":"<<t<<"\n";}
template<class T,class...S>void dbs(string str,T t,S... s){int idx=str.find(',');cout<<str.substr(0,idx)<<":"<<t<<",";dbs(str.substr(idx+1),s...);}
template<class T>ostream &operator<<(ostream &os, const deque<T>&d){os<<"[";for(auto&it:d) os << it << " ";return os<<"]";}
#endif
// Debugging Template ends
#define f                       first
#define s                       second
#define ARRAY_INPUT(arr, n)     for(int i = 0; i < n; i++) cin >> arr[i]
#define FORM(i, j, k, inc)       for(int i=j ; i<k ; i+=inc)
#define FOR(i,x)                for(int i = 0; i < x;i++)
#define mip(x)                  ll x;cin>>x
#define ip(x)                   cin>>x
#define pb                      push_back

using ll = long long;
using pii = pair<int,int>;
using pll = pair<ll,ll>;

using vi = vector<int>;
using vll = vector<long long>;
using vpii = vector<pii>;
using vpll = vector<pll>;

using vvi = vector<vector<int>>;
using vvll = vector<vector<long long>>;
using vvpii = vector<vector<pii>>;
using vvpll = vector<vector<pll>>;

using state = pll;

/*

    @author: Hetanshu Malik: June 14 2024

    Given an array with n values, find if it is possible to make
    a subset sum which is equal to Target value T

    Is famous problem called as : Subset Sum

    Is NP-Hard with usually TC of O(2^N) of generating all the subsets
    and then checking the values

    But due to lower constraints and repeated values it is possible
    to do this with DP

    During Coding:
    Here we have to merge the two choices of take and not take
    using OR operation as the quesiton asks if it possible to form
    a subset i.e. 0/1

*/

int n,T,q;
int arr[101];

int dp[101][10001];

int rec(int level, int sum){
    // Meaning: Is it possible to form a subset from [level..N]
    // sum equal to target T provided that we have processed
    // and calculated the sum of elements [0..level-1]

    // pruning
    if(sum > T) return 0;

    // basecase
    if(level == n){
        if(sum == T) return 1;
        else return 0;
    }

    // cache check
    if(dp[level][sum]!=-1)return dp[level][sum];

    // transition
    int donttake = rec(level+1,sum);
    int take = rec(level+1,sum+arr[level]);
    int ans = take || donttake;

    // save and return
    return dp[level][sum] = ans;
}

/*
    TC for printing is:
    For rec calls it is O(1)

    So it is O(N) for looping all over the array
*/


void printset(int level, int sum){
    if(level==n) return;
    
    cout << "Level, Sum:[" << level << ", " << sum << " ]\n";
    int donttake = rec(level+1,sum);
    int take = rec(level+1,sum+arr[level]);
    
    if(donttake == 1){
        printset(level+1,sum);
    }
    else if(take==1){
        cout << "Level, Element:[" << level << ", " << arr[level] << " ]\n";
        printset(level+1,sum+arr[level]);
    }

}


/*
    The above code does not work for queries form as using the above
    code would require us to memset or flush the dp array for each query

    If we do not flush: The way we have written code is that
    it is not dependent on T at all. The recursion calls happen
    independently of T and then same recursion calls of T/NT 
    with same sums will happen all over again.

    So say if we do rec for T=16, the required dp will be computed
    and stored. When we do the same call for T=18, the same rec
    calls will returned using cache check but T=18 requires new
    computation as rec(1,0) and rec(1,2) both give 1 for T=16
    but not the case for T=18, but it does give it which is WA

    That is why flusing is required to give correct answer which
    on queries form would explode my complexity

    If we do include T, then calls will be dependent on T and would
    give accurate answer
*/ 

int rec1(int level, int left){
    /*
        Meaning: Is is possible to make subset sum equal to T
        from [level .. N] provided we have sum left to make
        from [0..level-1]
    */
    
    // pruning
    if(left < 0) return 0;

    // basecase
    if(level==n){
        if(left == 0) return 1;
        else return 0;
    }

    // cache check
    if(dp[level][left]!=-1)return dp[level][left];

    // transition
    int donttake = rec1(level+1,left);
    int take = rec1(level+1,left - arr[level]);
    int ans = take || donttake;

    // save and return
    return dp[level][left] = ans;

}

void generate(int level, int left){
    if(level == n) return;

    int donttake = rec1(level+1, left);
    int take = rec1(level+1,left-arr[level]);
    if(donttake == 1){
        generate(level+1,left);
    }else if(take == 1){
        cout << "Level, Element:[" << level << ", " << arr[level] << " ]\n";
        generate(level+1,left-arr[level]);
    }
}

void solve(){
    cin >> n;
    ARRAY_INPUT(arr,n);

    pr(n);
    pr_arr(arr,n);

    memset(dp,-1,sizeof(dp));
    
    cin >> q;
    while(q--){
        cin >> T;
        cout << "For: " << T << "\n";
        cout << rec1(0,T) << "\n";
        if(rec(0,T)!=0){
            generate(0,T);
        }
        cout << "\n";
    }

}

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr); cout.tie(nullptr);

#ifndef ONLINE_JUDGE
    freopen("Input.txt","r",stdin);
    freopen("Output.txt","w",stdout);
    freopen("Error.txt","w",stderr);
    clock_t tStart = clock();
    cout<<fixed<<setprecision(10)<<"Time Taken: "<<(double)(clock()- tStart)/CLOCKS_PER_SEC<<endl;
#endif


    int t = 1;
    // cin >> t;
    while(t--){
        solve();
    }
}