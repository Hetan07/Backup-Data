#include<bits/stdc++.h>
using namespace std;

// Simple Debugging Template
#ifndef ONLINE_JUDGE
#define pr_arr(a,n)cout<<#a<<":";for(int i=0;i<n;i++)cout<<a[i]<<" ";cout<<endl;
#define pr_mat(mat,row,col)cout<<#mat<<":\n";for(int i=0;i<row;i++){for(int j=0;j<col;j++)cout<<mat[i][j]<<" ";cout<<endl;}
#define pr(...)dbs(#__VA_ARGS__,__VA_ARGS__)
template<class S,class T>ostream &operator<<(ostream &os,const pair<S,T> &p){return os<<"("<<p.first<<","<<p.second<<")";}
template<class T>ostream &operator<<(ostream &os,const vector<T> &p){os<<"[";for(auto&it:p)os<<it<<" ";return os<<"]";}
template<class T>ostream &operator<<(ostream &os,const set<T>&p){os<<"[";for(auto&it:p)os<<it<<" ";return os<<"]";}
template<class T>ostream &operator<<(ostream &os, const stack<T>&s){os<<"[";stack<T> temp(s);while (!temp.empty()){os << temp.top();temp.pop();if (!temp.empty())os << ", ";}return os << "]";}
template<class T>ostream &operator<<(ostream &os, const queue<T>&q){os<<"[";queue<T>temp(q);int size=temp.size();for(int i=0;i<size;i++){T front=temp.front();os<<front;temp.pop();if(i<size-1)os<< ", ";temp.push(front);}return os<< "]";}
template<class T>ostream &operator<<(ostream &os,const multiset<T>&p){os<<"[";for(auto&it:p)os<<it<<" ";return os<<"]";}
template<class T> ostream &operator<<(ostream &os, const priority_queue<T>&pq){os<<"[";priority_queue<T> temp(pq);while(!temp.empty()){os<<temp.top();temp.pop();if(!temp.empty()){os<<", ";}}return os << "]";}
template<class S,class T>ostream &operator<<(ostream &os,const map<S,T>&p){os<<"[";for(auto&it:p)os<<it<<" ";return os<<"]";}
template<class T>void dbs(string str,T t){cout<<str<<":"<<t<<"\n";}
template<class T,class...S>void dbs(string str,T t,S... s){int idx=str.find(',');cout<<str.substr(0,idx)<<":"<<t<<",";dbs(str.substr(idx+1),s...);}
template<class T>ostream &operator<<(ostream &os, const deque<T>&d){os<<"[";for(auto&it:d) os << it << " ";return os<<"]";}
#endif
// Debugging Template ends
#define f                       first
#define s                       second
#define ARRAY_INPUT(arr, n)     for(int i = 0; i < n; i++) cin >> arr[i]
#define FORM(i, j, k, inc)       for(int i=j ; i<k ; i+=inc)
#define FOR(i,x)                for(int i = 0; i < x;i++)
#define mip(x)                  ll x;cin>>x
#define ip(x)                   cin>>x
#define pb                      push_back

using ll = long long;
using pii = pair<int,int>;
using pll = pair<ll,ll>;

using vi = vector<int>;
using vll = vector<long long>;
using vpii = vector<pii>;
using vpll = vector<pll>;

using vvi = vector<vector<int>>;
using vvll = vector<vector<long long>>;
using vvpii = vector<vector<pii>>;
using vvpll = vector<vector<pll>>;

using state = pll;


/*

    @author: Hetanshu Malik: 14 June 2024

    Given an array, find the length of the 
    largest increasing subsequence

    Can be solved by both 
    - Form 1 
    - Form 2 

*/


int n;
vi arr;

int rec1(int level, int prev){
    /*
        Meaning: Max length of increasing subsequence from 
        [level .. N] given that we have prev from [0 .. level-1]
    

        without DP as here prev = -1 which means cannot store it
        in DP: need to modify
    */


    // pruning

    // basecase
    if(level == n) return 0;

    // cache check

    // transition
    
    int nt = rec1(level+1,prev);
    int ans = nt;
    if(prev==-1 || arr[level] > arr[prev]){
        int t = 1 + rec1(level+1,level);
        ans = max(ans,t);
    }

    // save and return
    return ans;
}

int dp_x[1001][1002];

int dp1(int level, int prev){
    /*
        Meaning: Max length of increasing subsequence from 
        [level .. N] given that we have prev from [0 .. level-1]

        With DP: Just shifted each value by 1: Basically 1-indexing    

    */


    // pruning

    // basecase
    if(level == n+1) return 0;

    // cache check
    if(dp_x[level][prev]!=-1) return dp_x[level][prev];

    // transition
    
    int nt = dp1(level+1,prev);
    int ans = nt;
    if(prev==0 || arr[level-1] > arr[prev-1]){
        int t = 1 + dp1(level+1,level);
        ans = max(ans,t);
    }

    // save and return
    return dp_x[level][prev] = ans;
}

int dp[100010];

int rec(int level){
    /*
    Meaning: Best or max length LIS ending at level i.e. from [0..level]
    */

    // pruning

    // basecase
    if(level<0)return 0;

    // cache check
    if(dp[level]!=-1)return dp[level];

    // transition
    int ans = 1; // st and ending at i
    for(int i = 0; i < level; i++){
        if(arr[level] > arr[i]){
            ans = max(ans, 1+rec(i));
        }
    }

    // save and return
    return dp[level]=ans;
}



void solve(){
    cin >> n;
    arr.resize(n);
    ARRAY_INPUT(arr,n);

    // cout << rec1(0,-1)<<"\n";
    
    // memset(dp_x,-1,sizeof(dp_x));
    // cout << dp1(1,0);

    memset(dp,-1,sizeof(dp));
    int ans = 0;
    for(int i = 0; i < n; i++){
        ans = max(ans, rec(i));
    }
    /*Get the best answer by finding the best with all the endings at i*/
    pr(ans);
}

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr); cout.tie(nullptr);

#ifndef ONLINE_JUDGE
    freopen("Input.txt","r",stdin);
    freopen("Output.txt","w",stdout);
    freopen("Error.txt","w",stderr);
    clock_t tStart = clock();
    cout<<fixed<<setprecision(10)<<"Time Taken: "<<(double)(clock()- tStart)/CLOCKS_PER_SEC<<endl;
#endif


    int t = 1;
    // cin >> t;
    while(t--){
        solve();
    }
}