#include<bits/stdc++.h>
using namespace std;

// Simple Debugging Template
#ifndef ONLINE_JUDGE
#define pr_arr(a,n)cout<<#a<<":";for(int i=0;i<n;i++)cout<<a[i]<<" ";cout<<endl;
#define pr_mat(mat,row,col)cout<<#mat<<":\n";for(int i=0;i<row;i++){for(int j=0;j<col;j++)cout<<mat[i][j]<<" ";cout<<endl;}
#define pr(...)dbs(#__VA_ARGS__,__VA_ARGS__)
template<class S,class T>ostream &operator<<(ostream &os,const pair<S,T> &p){return os<<"("<<p.first<<","<<p.second<<")";}
template<class T>ostream &operator<<(ostream &os,const vector<T> &p){os<<"[";for(auto&it:p)os<<it<<" ";return os<<"]";}
template<class T>ostream &operator<<(ostream &os,const set<T>&p){os<<"[";for(auto&it:p)os<<it<<" ";return os<<"]";}
template<class T>ostream &operator<<(ostream &os, const stack<T>&s){os<<"[";stack<T> temp(s);while (!temp.empty()){os << temp.top();temp.pop();if (!temp.empty())os << ", ";}return os << "]";}
template<class T>ostream &operator<<(ostream &os, const queue<T>&q){os<<"[";queue<T>temp(q);int size=temp.size();for(int i=0;i<size;i++){T front=temp.front();os<<front;temp.pop();if(i<size-1)os<< ", ";temp.push(front);}return os<< "]";}
template<class T>ostream &operator<<(ostream &os,const multiset<T>&p){os<<"[";for(auto&it:p)os<<it<<" ";return os<<"]";}
template<class T> ostream &operator<<(ostream &os, const priority_queue<T>&pq){os<<"[";priority_queue<T> temp(pq);while(!temp.empty()){os<<temp.top();temp.pop();if(!temp.empty()){os<<", ";}}return os << "]";}
template<class S,class T>ostream &operator<<(ostream &os,const map<S,T>&p){os<<"[";for(auto&it:p)os<<it<<" ";return os<<"]";}
template<class T>void dbs(string str,T t){cout<<str<<":"<<t<<"\n";}
template<class T,class...S>void dbs(string str,T t,S... s){int idx=str.find(',');cout<<str.substr(0,idx)<<":"<<t<<",";dbs(str.substr(idx+1),s...);}
template<class T>ostream &operator<<(ostream &os, const deque<T>&d){os<<"[";for(auto&it:d) os << it << " ";return os<<"]";}
#endif
// Debugging Template ends
#define f                       first
#define s                       second
#define ARRAY_INPUT(arr, n)     for(int i = 0; i < n; i++) cin >> arr[i]
#define FORM(i, j, k, inc)      for(int i=j ; i<k ; i+=inc)
#define FOR(i,x)                for(int i = 0; i < x;i++)
#define mip(x)                  ll x;cin>>x
#define ip(x)                   cin>>x
#define pb                      push_back

using ll = long long;
using pii = pair<int,int>;
using pll = pair<ll,ll>;

using vi = vector<int>;
using vll = vector<long long>;
using vpii = vector<pii>;
using vpll = vector<pll>;

using vvi = vector<vector<int>>;
using vvll = vector<vector<long long>>;
using vvpii = vector<vector<pii>>;
using vvpll = vector<vector<pll>>;

/*
    Given a string, break/partition the string into several substrings such
    as to make each substring a palindrome. We want to minimize the number of breaks
    required for this.

-------------------------------------------------------------
    General Note

    Whenever we have to decompose an arr into smaller subarrs
    - Form 2/4 is used

    If we have to check ranges in a jumpy format, we tend to use 
    - Form 2
    - There is sort of 1:1 correspondence with subarrs/subsequence
    `i` on which we jump upon using Form 2 can be seen as the ending of an subarr

--------------------------------------------------------------
    A Classical Problem

    This question in itself is hidden of two questions
    1. Check Palindrome
    2. Form the Cuts

    For the first problem, it is easy to check palindrome in O(N) manner
    but when given in query format, say Q queries with [L..R], It becomes O(Q*N)

    Q<=1e6 and N<=1e3 becomes O(1e9) which give TLE

    Naturally, we can do a preprocessing step using DP which stores is it possible
    to have a palindrome of string from [L..R] in O(n^2) = O(1e6) and then each query
    can be solved in O(1)

    This has a simple transition
    ans = 0
    if(s[L]==s[R]){
        ans = rec(L+1,R-1); 
    }

    Some faster algo like Manacher algo for this task also exists

*/
int n;
string s;

int dp1[1001][1001]; // Stores if s[L..R] is palindrome or not

int rec(int l, int r){
    /*
        Meaning: Returns if s[L to R] is a palindrome or not;
        0-based indexing
    */

    //basecase
    if(l>=r) return 1;

    //cache check
    if(dp1[l][r]!=-1)return dp1[l][r];

    int ans = 0;
    if(s[l] == s[r]){
        ans = rec(l+1,r-1);
    }
    return dp1[l][r]=ans;
}

/*
    The second part of the problem is about forming the cuts can be done by
    - Form 2 (Choosing the partition in jumpy manner)
    - Form 1 (Choosing the partition at `ith` or T/NT the partition)
    - Form 4 (Choosing the partition from [L..R])

    Using Form 2 as N eas 1e3 here and usually Form 4 is often not chosen when n>=1e3
    as it often leads to solutions of being(O(n^2/n^3));

    Note that the recurrence is written in 1-based indexing as:
    Transition was:
    for(int j = i-1; j>=0;j--){
        if(rec(j,i-1)){ // Check
            ans = min(ans, rec2(j)+1);
        } 
    }

    For [aba], the optimal answer = 0, When we call the rec: the optimal is present
    for j = -1 [when 0-based indexing]. If we return 0, ans = 1, so we return -1
    to offset that 1 for these cases

    But if we want to memoize it, we need to store dp[-1] which is not possible,
    So either, we use 0-based indexing (also works) or 1-based indexing

*/

int dp2[1001];

int rec2(int i){
    /*
        Minimum cuts to make substrings of string ending at i 
    */

    //pruning

    //basecase
    if(i==-1)return -1; // Because of the way we wrote recurrence (0-based)
    // if(i==0)return -1;// (1-based)

    //cache check
    if(dp2[i]!=-1)return dp2[i];

    //transition
    int ans = 1e9;
    for(int j = i-1; j>=-1;j--){
        if(rec(j+1,i)){ // Check Palindrome: Acts like O(1). Note we call rec and not dp[j+1][i]
            ans = min(ans, rec2(j)+1);
        } 
    }

    return dp2[i]=ans;

    //save and return

}

void solve(){
    cin >> s;
    n = s.size();

    memset(dp1,-1,sizeof(dp1));
    memset(dp2,-1,sizeof(dp2));

    cout << rec2(n-1);

}

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr); cout.tie(nullptr);

#ifndef ONLINE_JUDGE
    freopen("Input.txt","r",stdin);
    freopen("Output.txt","w",stdout);
    freopen("Error.txt","w",stderr);
    clock_t tStart = clock();
    cout<<fixed<<setprecision(10)<<"Time Taken: "<<(double)(clock()- tStart)/CLOCKS_PER_SEC<<endl;
#endif


    int t = 1;
    // cin >> t;
    while(t--){
        solve();
    }
}