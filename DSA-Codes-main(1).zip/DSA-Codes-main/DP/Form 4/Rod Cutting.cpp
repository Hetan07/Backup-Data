#include<bits/stdc++.h>
using namespace std;

// Simple Debugging Template
#ifndef ONLINE_JUDGE
#define pr_arr(a,n)cout<<#a<<":";for(int i=0;i<n;i++)cout<<a[i]<<" ";cout<<endl;
#define pr_mat(mat,row,col)cout<<#mat<<":\n";for(int i=0;i<row;i++){for(int j=0;j<col;j++)cout<<mat[i][j]<<" ";cout<<endl;}
#define pr(...)dbs(#__VA_ARGS__,__VA_ARGS__)
template<class S,class T>ostream &operator<<(ostream &os,const pair<S,T> &p){return os<<"("<<p.first<<","<<p.second<<")";}
template<class T>ostream &operator<<(ostream &os,const vector<T> &p){os<<"[";for(auto&it:p)os<<it<<" ";return os<<"]";}
template<class T>ostream &operator<<(ostream &os,const set<T>&p){os<<"[";for(auto&it:p)os<<it<<" ";return os<<"]";}
template<class T>ostream &operator<<(ostream &os, const stack<T>&s){os<<"[";stack<T> temp(s);while (!temp.empty()){os << temp.top();temp.pop();if (!temp.empty())os << ", ";}return os << "]";}
template<class T>ostream &operator<<(ostream &os, const queue<T>&q){os<<"[";queue<T>temp(q);int size=temp.size();for(int i=0;i<size;i++){T front=temp.front();os<<front;temp.pop();if(i<size-1)os<< ", ";temp.push(front);}return os<< "]";}
template<class T>ostream &operator<<(ostream &os,const multiset<T>&p){os<<"[";for(auto&it:p)os<<it<<" ";return os<<"]";}
template<class T> ostream &operator<<(ostream &os, const priority_queue<T>&pq){os<<"[";priority_queue<T> temp(pq);while(!temp.empty()){os<<temp.top();temp.pop();if(!temp.empty()){os<<", ";}}return os << "]";}
template<class S,class T>ostream &operator<<(ostream &os,const map<S,T>&p){os<<"[";for(auto&it:p)os<<it<<" ";return os<<"]";}
template<class T>void dbs(string str,T t){cout<<str<<":"<<t<<"\n";}
template<class T,class...S>void dbs(string str,T t,S... s){int idx=str.find(',');cout<<str.substr(0,idx)<<":"<<t<<",";dbs(str.substr(idx+1),s...);}
template<class T>ostream &operator<<(ostream &os, const deque<T>&d){os<<"[";for(auto&it:d) os << it << " ";return os<<"]";}
#endif
// Debugging Template ends
#define f                       first
#define s                       second
#define ARRAY_INPUT(arr, n)     for(int i = 0; i < n; i++) cin >> arr[i]
#define FORM(i, j, k, inc)      for(int i=j ; i<k ; i+=inc)
#define FOR(i,x)                for(int i = 0; i < x;i++)
#define mip(x)                  ll x;cin>>x
#define ip(x)                   cin>>x
#define pb                      push_back

using ll = long long;
using pii = pair<int,int>;
using pll = pair<ll,ll>;

using vi = vector<int>;
using vll = vector<long long>;
using vpii = vector<pii>;
using vpll = vector<pll>;

using vvi = vector<vector<int>>;
using vvll = vector<vector<long long>>;
using vvpii = vector<vector<pii>>;
using vvpll = vector<vector<pll>>;

/*
    Rod Cutting Problem:

    Given n break points with the length of the rod being `tot`, find the
    minimum cost to break it into n-1 pieces where cost = length of the segment of the
    rod being broken


    Greedy doesn't work but I don't have a full blown proof/intuition behind it
    But an example testcase where it fails is x = [4,5,6]. Any greedy hueristic most likely
    tries to cut in the middle of the length of the rod which in this case means
    choosing first 5, then 4/6 with cost = 20. But optimal is 4,6,5 which leads to
    10 + 6 + 2 = 18

    Anyways, a common example of LR DP - Form 4

    A common thing to note about this problem is that the range over which we divide
    the problem is dictated by the x/cuts array. Our mid will iterate over this array
    as we can break only on these points. So to get the proper answer, we must do

    - X[0] = 0
    - x[total_cuts+1] = total_length;

    Transition
    dp(L,R) = dp(L,mid) + dp(mid,R) + (x[R] - x[L]);

    A few points to make about this transition
    - We loop over mid
    - in a way, basecase is a single unit of rod, dp(L,mid=L) doesn't make sense
    it has to be dp(L,mid=L+1). Similarly, dp(mid=R,R) doesn't make sense as we don't have
    a rod there, dp(mid=R-1,R) makes sense

    Basecase has to be set perfectly, L+1==R indicates a single unit and we should return 0
    from here.

    TL Check
    #s = n*n
    #t = n
    TC of O(n^3)

*/

int n; // break points
int tot; // Total length of the rod;
int x[1001]; // The distance counted from 0 at which x[i] breakpoint lies

int dp[111][111];

int rec(int l, int r){
    /*
        Minimum cost to break the rod from [L .. R]
    */
    //pruning

    //basecase
    if(l+1==r){
        return 0;
    }

    //cache check
    if(dp[l][r]!=-1)return dp[l][r];

    //transition
    int ans = 1e9; // Minimization problem
    for(int mid = l+1; mid < r; mid++){
        ans = min(ans, rec(l,mid)+rec(mid,r)+(x[r]-x[l]));
    }

    //save and return
    return dp[l][r]=ans;

}

void solve(){
    cin >> n >> tot;
    for(int i = 1; i <= n;i++)cin >> x[i];
    
    // basecases
    x[0] = 0;
    x[n+1] = tot;

    memset(dp,-1,sizeof(dp));

    cout << rec(0,n+1);
}

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr); cout.tie(nullptr);

#ifndef ONLINE_JUDGE
    freopen("Input.txt","r",stdin);
    freopen("Output.txt","w",stdout);
    freopen("Error.txt","w",stderr);
    clock_t tStart = clock();
    cout<<fixed<<setprecision(10)<<"Time Taken: "<<(double)(clock()- tStart)/CLOCKS_PER_SEC<<endl;
#endif


    int t = 1;
    // cin >> t;
    while(t--){
        solve();
    }
}