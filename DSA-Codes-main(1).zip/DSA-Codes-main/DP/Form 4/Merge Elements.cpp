#include<bits/stdc++.h>
using namespace std;

// Simple Debugging Template
#ifndef ONLINE_JUDGE
#define pr_arr(a,n)cout<<#a<<":";for(int i=0;i<n;i++)cout<<a[i]<<" ";cout<<endl;
#define pr_mat(mat,row,col)cout<<#mat<<":\n";for(int i=0;i<row;i++){for(int j=0;j<col;j++)cout<<mat[i][j]<<" ";cout<<endl;}
#define pr(...)dbs(#__VA_ARGS__,__VA_ARGS__)
template<class S,class T>ostream &operator<<(ostream &os,const pair<S,T> &p){return os<<"("<<p.first<<","<<p.second<<")";}
template<class T>ostream &operator<<(ostream &os,const vector<T> &p){os<<"[";for(auto&it:p)os<<it<<" ";return os<<"]";}
template<class T>ostream &operator<<(ostream &os,const set<T>&p){os<<"[";for(auto&it:p)os<<it<<" ";return os<<"]";}
template<class T>ostream &operator<<(ostream &os, const stack<T>&s){os<<"[";stack<T> temp(s);while (!temp.empty()){os << temp.top();temp.pop();if (!temp.empty())os << ", ";}return os << "]";}
template<class T>ostream &operator<<(ostream &os, const queue<T>&q){os<<"[";queue<T>temp(q);int size=temp.size();for(int i=0;i<size;i++){T front=temp.front();os<<front;temp.pop();if(i<size-1)os<< ", ";temp.push(front);}return os<< "]";}
template<class T>ostream &operator<<(ostream &os,const multiset<T>&p){os<<"[";for(auto&it:p)os<<it<<" ";return os<<"]";}
template<class T> ostream &operator<<(ostream &os, const priority_queue<T>&pq){os<<"[";priority_queue<T> temp(pq);while(!temp.empty()){os<<temp.top();temp.pop();if(!temp.empty()){os<<", ";}}return os << "]";}
template<class S,class T>ostream &operator<<(ostream &os,const map<S,T>&p){os<<"[";for(auto&it:p)os<<it<<" ";return os<<"]";}
template<class T>void dbs(string str,T t){cout<<str<<":"<<t<<"\n";}
template<class T,class...S>void dbs(string str,T t,S... s){int idx=str.find(',');cout<<str.substr(0,idx)<<":"<<t<<",";dbs(str.substr(idx+1),s...);}
template<class T>ostream &operator<<(ostream &os, const deque<T>&d){os<<"[";for(auto&it:d) os << it << " ";return os<<"]";}
#endif
// Debugging Template ends
#define f                       first
#define s                       second
#define ARRAY_INPUT(arr, n)     for(int i = 0; i < n; i++) cin >> arr[i]
#define FORM(i, j, k, inc)      for(int i=j ; i<k ; i+=inc)
#define FOR(i,x)                for(int i = 0; i < x;i++)
#define mip(x)                  ll x;cin>>x
#define ip(x)                   cin>>x
#define pb                      push_back

using ll = long long;
using pii = pair<int,int>;
using pll = pair<ll,ll>;

using vi = vector<int>;
using vll = vector<long long>;
using vpii = vector<pii>;
using vpll = vector<pll>;

using vvi = vector<vector<int>>;
using vvll = vector<vector<long long>>;
using vvpii = vector<vector<pii>>;
using vvpll = vector<vector<pll>>;

/*

    Merge Consecutive Elements till we get only a single element (Like MCM)

    Given n objects with some value A[i], find the maximum sum of all benefits 
    we can get where the benefit when merging two elements is A[i]*A[j] and the 
    new value of the merged object is (A[i]+A[j])%100

-------------------------------------------------------------

    Now, Greedy doesn't work in also a unique way here, we are doing a modulo 100,
    so when we merge it might happen is that when we pick the pair with the maximum
    value, correspondingly, the new value will be a lot less

    eg [30 50 50] -> [30 0] -> 30. Benefit = 2500
    Optimal [30 50 50] -> [80 50] -> [30], Benefit = 1500+4000

    Constraints, n<=500 or around 1e2.

    Note, such constraints indicate that Form - 4 has to be used as it often supports
    solutions of O(n^2/n^3)

-------------------------------------------------------------

    Why not Form 2?

    Form 2 cannot processes nested merging, can handle only distinct merging

--------------------------------------------------------------

The way to think about such questions is to start from the end/final result
and see how it came about from the previous states

--------------------------------------------------------------

DP meaning: dp(l,r): Maximum benefit obtained from arr[l..r]

Transition
Iterate over the break point/partition point, say mid
dp(l,r) = for all mids (max(ans, dp(l,mid) + dp(mid+1,r) + [(val of left subarr) * (val of right subarr) ] ))

Interesting: In my own first try, cannot deduce how to calculate the value itself.



*/

int n;
vi arr;

int dp[111][111];

int rec(int l, int r){
    /*
        Meaning: Max benefit from arr[l .. r] where l and r are indices of the target subarr
    */

    //basecase
    if(l ==r) return 0; // single element

    //cache check
    if(dp[l][r]!=-1)return dp[l][r];

    //transition
    int ans = -1e9;

    // Calculating sum from l to r
    int tot = 0;
    for(int i = l; i<=r;i++){
        tot+=arr[i];
    }

    int sum = 0;
    for(int mid = l; mid <r;mid++){
        sum+=arr[mid];
        ans = max( ans , rec(l,mid) + rec(mid+1, r) + (sum%100)*((tot-sum)%100));
    }

    //save and return
    return dp[l][r]=ans;

}


void solve(){
    cin >> n;
    arr.resize(n);
    for(int i = 0; i < n;i++)cin>>arr[i];

    memset(dp,-1,sizeof(dp));

    cout << rec(0,n-1);

}

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr); cout.tie(nullptr);

#ifndef ONLINE_JUDGE
    freopen("Input.txt","r",stdin);
    freopen("Output.txt","w",stdout);
    freopen("Error.txt","w",stderr);
    clock_t tStart = clock();
    cout<<fixed<<setprecision(10)<<"Time Taken: "<<(double)(clock()- tStart)/CLOCKS_PER_SEC<<endl;
#endif


    int t = 1;
    // cin >> t;
    while(t--){
        solve();
    }
}