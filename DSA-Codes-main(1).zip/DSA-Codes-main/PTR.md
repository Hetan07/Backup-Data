# PTR

Just for some random references

FUTURE COMMENT: Container jaise ki vector ka if arr[n] use kare
KAAFI baar instead of undefined, 0 return ho jaaye, to possibly
locally kaam kar jaaye but online judge TLE maare


Agar kabhi dp ka problem solve karte hue default value aa rahi say 1e9 or -1e9 or 0
and also in general agar recursion answer return kar raha hai and it is wrong
CHECK THE BASECASES!

IN LR DP problems, vital to know the bounds
when iterating over break points
mid = l or l+1, ending mid $r-1$ or $r$
and then also noticing the bounds of the recursive calls
(l,mid) or(mid+1,r) or(mid,r)