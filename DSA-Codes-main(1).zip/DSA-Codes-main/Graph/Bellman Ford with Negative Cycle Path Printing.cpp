#include<bits/stdc++.h>
using namespace std;
 
// Simple Debugging Template
#ifndef ONLINE_JUDGE
#define pr_arr(a,n)cout<<#a<<":";for(int i=0;i<n;i++)cout<<a[i]<<" ";cout<<endl;
#define pr_mat(mat,row,col)cout<<#mat<<":\n";for(int i=0;i<row;i++){for(int j=0;j<col;j++)cout<<mat[i][j]<<" ";cout<<endl;}
#define pr(...)dbs(#__VA_ARGS__,__VA_ARGS__)
template<class S,class T>ostream &operator<<(ostream &os,const pair<S,T> &p){return os<<"("<<p.first<<","<<p.second<<")";}
template<class T>ostream &operator<<(ostream &os,const vector<T> &p){os<<"[";for(auto&it:p)os<<it<<" ";return os<<"]";}
template<class T>ostream &operator<<(ostream &os,const set<T>&p){os<<"[";for(auto&it:p)os<<it<<" ";return os<<"]";}
template<class T>ostream &operator<<(ostream &os, const stack<T>&s){os<<"[";stack<T> temp(s);while (!temp.empty()){os << temp.top();temp.pop();if (!temp.empty())os << ", ";}return os << "]";}
template<class T>ostream &operator<<(ostream &os, const queue<T>&q){os<<"[";queue<T>temp(q);int size=temp.size();for(int i=0;i<size;i++){T front=temp.front();os<<front;temp.pop();if(i<size-1)os<< ", ";temp.push(front);}return os<< "]";}
template<class T>ostream &operator<<(ostream &os,const multiset<T>&p){os<<"[";for(auto&it:p)os<<it<<" ";return os<<"]";}
template<class T> ostream &operator<<(ostream &os, const priority_queue<T>&pq){os<<"[";priority_queue<T> temp(pq);while(!temp.empty()){os<<temp.top();temp.pop();if(!temp.empty()){os<<", ";}}return os << "]";}
template<class S,class T>ostream &operator<<(ostream &os,const map<S,T>&p){os<<"[";for(auto&it:p)os<<it<<" ";return os<<"]";}
template<class T>void dbs(string str,T t){cout<<str<<":"<<t<<"\n";}
template<class T,class...S>void dbs(string str,T t,S... s){int idx=str.find(',');cout<<str.substr(0,idx)<<":"<<t<<",";dbs(str.substr(idx+1),s...);}
template<class T>ostream &operator<<(ostream &os, const deque<T>&d){os<<"[";for(auto&it:d) os << it << " ";return os<<"]";}
 
#else
#define pr(...){}
#define debarr(a,n){}
#define debmat(mat,row,col){}
#endif
// Debugging Template ends
#define f                       first
#define s                       second
#define ARRAY_INPUT(arr, n)     for(int i = 0; i < n; i++) cin >> arr[i]
#define FORM(i,j,k,inc)         for (int i=j ; i<k ; i+=inc)
#define FOR(i,x)                for(int i = 0; i < x;i++)
#define mip(x)                  ll x;cin>>x
#define ip(x)                   cin>>x
#define pb                      push_back
 
using ll = long long;
using pii = pair<int,int>;
using pll = pair<ll,ll>;
 
using vi = vector<int>;
using vll = vector<long long>;
using vpii = vector<pii>;
using vpll = vector<pll>;
 
using vvi = vector<vector<int>>;
using vvll = vector<vector<long long>>;
using vvpii = vector<vector<pii>>;
using vvpll = vector<vector<pll>>;
 
using state = pll;
 
 
struct Edge{
    ll a,b,cost;
};
 
ll n,m;
 
vector<Edge> edges;
vll d;
vll p;
 
 
void printer(){
    cout << "edges:[";
    for(auto x:edges){
        cout << "[(" << x.a << " ," << x.b << " ," << x.cost << ")] ";
    }
    cout << "]\n";
}
 
 
void solve(){
    cin >> n >> m;
    d.assign(n+1,1e18);
    p.assign(n+1,-1);
    FOR(i,m){
        mip(a);mip(b);mip(c);
        Edge temp;
        temp.a = a;
        temp.b = b;
        temp.cost = c;
        edges.pb(temp);
    }
 
    // Bellman Ford: Tpyically n-1 iterations with one more iteration to detect the negative cycle

    // Can be compressed to do it in n iterations

     
    //Source Node : Pick any, as we allow all the edges (and nodes) to be relaxed irrespective of 
    // reachability from the src
    d[1] = 0;
    ll x; // Act as detection of cycle and the last relaxed vertex
    for (int i = 0; i < n; ++i) {
        x = -1;
        for (Edge e : edges){
            // if(dis[e.a] != INF/ 1e18) -> To allow only nodes reachable from src to be relaxed
                if (d[e.b] > d[e.a] + e.cost) {
                    d[e.b] = d[e.a] + e.cost;
                    p[e.b] = e.a;
                    x = e.b;
                }
        }
    }
    pr(d);
    pr(p);
    if (x == -1)
        cout << "NO\n";
    else{
        cout << "YES\n";
        int y = x; // Looping to guaranteed get the vertex part of the negative cycle
        for (int i = 0; i < n; i++){
            y = p[y];
        }    
        vector<int> path;
        int cur = y;
        while(true){
            if(cur == y && path.size() > 1){
                break;
            }
            path.pb(cur);
            cur = p[cur];
        }
        // This while loop will get all the vertices of the negative cycle using the par array.
 
        reverse(path.begin(), path.end()); 
        // Reverse is necessary to get the proper direction of the edges of the cycle
        
        for (int u : path)
            cout << u << ' ';
    }

    
 
}
 
int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr); cout.tie(nullptr);
 
#ifndef ONLINE_JUDGE
    freopen("Input.txt","r",stdin);
    freopen("Output.txt","w",stdout);
    freopen("Error.txt","w",stderr);
    clock_t tStart = clock();
    cout<<fixed<<setprecision(10)<<"\nTime Taken: "<<(double)(clock()- tStart)/CLOCKS_PER_SEC<<endl;
#endif
 
 
    int t = 1;
    // cin >> t;
    while(t--){
        solve();
    }

    
}
 
//1 5 2
// 5 6 -3 
// 5 7 -5
// 5 8 1
// 8 10 -2
// 10 9 3
// 9 5 4
// 1 11 7
// 11 12 1
// 12 13 -2
// 7 9 -5

