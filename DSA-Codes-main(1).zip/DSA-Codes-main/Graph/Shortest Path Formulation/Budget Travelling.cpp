#include<bits/stdc++.h>
using namespace std;

// Simple Debugging Template
#ifndef ONLINE_JUDGE
#define pr_arr(a,n)cout<<#a<<":";for(int i=0;i<n;i++)cout<<a[i]<<" ";cout<<endl;
#define pr_mat(mat,row,col)cout<<#mat<<":\n";for(int i=0;i<row;i++){for(int j=0;j<col;j++)cout<<mat[i][j]<<" ";cout<<endl;}
#define pr(...)dbs(#__VA_ARGS__,__VA_ARGS__)
template<class S,class T>ostream &operator<<(ostream &os,const pair<S,T> &p){return os<<"("<<p.first<<","<<p.second<<")";}
template<class T>ostream &operator<<(ostream &os,const vector<T> &p){os<<"[";for(auto&it:p)os<<it<<" ";return os<<"]";}
template<class T>ostream &operator<<(ostream &os,const set<T>&p){os<<"[";for(auto&it:p)os<<it<<" ";return os<<"]";}
template<class T>ostream &operator<<(ostream &os, const stack<T>&s){os<<"[";stack<T> temp(s);while (!temp.empty()){os << temp.top();temp.pop();if (!temp.empty())os << ", ";}return os << "]";}
template<class T>ostream &operator<<(ostream &os, const queue<T>&q){os<<"[";queue<T>temp(q);int size=temp.size();for(int i=0;i<size;i++){T front=temp.front();os<<front;temp.pop();if(i<size-1)os<< ", ";temp.push(front);}return os<< "]";}
template<class T>ostream &operator<<(ostream &os,const multiset<T>&p){os<<"[";for(auto&it:p)os<<it<<" ";return os<<"]";}
template<class T> ostream &operator<<(ostream &os, const priority_queue<T>&pq){os<<"[";priority_queue<T> temp(pq);while(!temp.empty()){os<<temp.top();temp.pop();if(!temp.empty()){os<<", ";}}return os << "]";}
template<class S,class T>ostream &operator<<(ostream &os,const map<S,T>&p){os<<"[";for(auto&it:p)os<<it<<" ";return os<<"]";}
template<class T>void dbs(string str,T t){cout<<str<<":"<<t<<"\n";}
template<class T,class...S>void dbs(string str,T t,S... s){int idx=str.find(',');cout<<str.substr(0,idx)<<":"<<t<<",";dbs(str.substr(idx+1),s...);}
template<class T>ostream &operator<<(ostream &os, const deque<T>&d){os<<"[";for(auto&it:d) os << it << " ";return os<<"]";}

#else
#define pr(...){}
#define debarr(a,n){}
#define debmat(mat,row,col){}
#endif
// Debugging Template ends
#define f                       first
#define s                       second
#define ARRAY_INPUT(arr, n)     for(int i = 0; i < n; i++) cin >> arr[i]
#define FORM(i, j, k, inc)      for(int i=j ; i<k ; i+=inc)
#define FOR(i,x)                for(int i = 0; i < x;i++)
#define mip(x)                  ll x;cin>>x
#define ip(x)                   cin>>x
#define pb                      push_back

using ll = long long;
using pii = pair<int,int>;
using pll = pair<ll,ll>;

using vi = vector<int>;
using vll = vector<long long>;
using vpii = vector<pii>;
using vpll = vector<pll>;

using vvi = vector<vector<int>>;
using vvll = vector<vector<long long>>;
using vvpii = vector<vector<pii>>;
using vvpll = vector<vector<pll>>;

using state = pll;

ll n,m;
vvpll g;
vll p;
ll a,b,c;

// vvll dis(10010,vll(101,1e18));
// vvll vis(10010,vll(101,0));
vvll dis;
vvll vis;
void dijkstra(state st){
	// pq < dis, node to process > 
	// pq < dis, node and cur fuel>
	priority_queue<pair<ll,pll>> pq;

	// Set the dist of st as all zero
	dis[st.f][st.s] = 0;
	
	// push st to pq: cost of src, node to process 
	pq.push({-0,st});

	// while pq is not empty:
	while(!pq.empty()){

		// process the current node 
		// 0. Pop it out of pq.
		auto it = pq.top();pq.pop();
		ll cur_dis = -it.f;
		ll node = it.s.f;
		ll fuel = it.s.s;

		// 1: Set it visited
		if(vis[node][fuel] == 1) continue;
		vis[node][fuel] = 1;

		// 2. Go over all the neighbours
		for(auto v: g[node]){

			// Relax the neighbour if possible
			// possibility : 
			if(fuel >= v.s){

				// dis[neighbour] > dis[cur_nod] + (0) -> As no cost is taken
				// dis[v.f][neighbour_fuel] > dis[node][fuel] + (0)
				if(dis[v.f][fuel-v.s] > dis[node][fuel] + 0){
					dis[v.f][fuel-v.s] = dis[node][fuel] + 0;
					pq.push({-dis[v.f][fuel-v.s],{v.f,fuel-v.s}});
				}
			}
		}
		// Always the option to refill
		if(fuel < c){
			if(dis[node][fuel+1] > dis[node][fuel] + p[node]){
				dis[node][fuel+1] = dis[node][fuel] + p[node];
				pq.push({-dis[node][fuel+1],{node,fuel+1}});
			}
		}
	}
}

void solve(){
    ip(n);ip(m);
    g.resize(n+1);
    FOR(i,m){
        mip(u);mip(v);mip(d);
        g[u].pb({v,d});
        g[v].pb({u,d});
    }
    p.resize(n+1);
	

	FOR(i,n) cin >> p[i+1];

	ip(a);ip(b);ip(c);

	pr(g);
	pr(p);
	pr(a,b,c);

	dis.assign(n+1,vll(c+1,1e9));
	vis.assign(n+1,vll(c+1,0));
	// pr(dis);

	state st = {a,0};
	// S.f   S.s
	// Node, Current Fuel

	dijkstra(st);
	pr(dis);
	pr(vis);
	pr(dis[b][0]);
	cout << dis[b][0];

}

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr); cout.tie(nullptr);

#ifndef ONLINE_JUDGE
    freopen("Input.txt","r",stdin);
    freopen("Output.txt","w",stdout);
    freopen("Error.txt","w",stderr);
    clock_t tStart = clock();
    cout<<fixed<<setprecision(10)<<"Time Taken: "<<(double)(clock()- tStart)/CLOCKS_PER_SEC<<"\n";
#endif


    int t = 1;
    // cin >> t;
    while(t--){
        solve();
    }
}