#include<bits/stdc++.h>
using namespace std;

// Simple Debugging Template
#ifndef ONLINE_JUDGE
#define pr_arr(a,n)cout<<#a<<":";for(int i=0;i<n;i++)cout<<a[i]<<" ";cout<<endl;
#define pr_mat(mat,row,col)cout<<#mat<<":\n";for(int i=0;i<row;i++){for(int j=0;j<col;j++)cout<<mat[i][j]<<" ";cout<<endl;}
#define pr(...)dbs(#__VA_ARGS__,__VA_ARGS__)
template<class S,class T>ostream &operator<<(ostream &os,const pair<S,T> &p){return os<<"("<<p.first<<","<<p.second<<")";}
template<class T>ostream &operator<<(ostream &os,const vector<T> &p){os<<"[";for(auto&it:p)os<<it<<" ";return os<<"]";}
template<class T>ostream &operator<<(ostream &os,const set<T>&p){os<<"[";for(auto&it:p)os<<it<<" ";return os<<"]";}
template<class T>ostream &operator<<(ostream &os, const stack<T>&s){os<<"[";stack<T> temp(s);while (!temp.empty()){os << temp.top();temp.pop();if (!temp.empty())os << ", ";}return os << "]";}
template<class T>ostream &operator<<(ostream &os, const queue<T>&q){os<<"[";queue<T>temp(q);int size=temp.size();for(int i=0;i<size;i++){T front=temp.front();os<<front;temp.pop();if(i<size-1)os<< ", ";temp.push(front);}return os<< "]";}
template<class T>ostream &operator<<(ostream &os,const multiset<T>&p){os<<"[";for(auto&it:p)os<<it<<" ";return os<<"]";}
template<class T> ostream &operator<<(ostream &os, const priority_queue<T>&pq){os<<"[";priority_queue<T> temp(pq);while(!temp.empty()){os<<temp.top();temp.pop();if(!temp.empty()){os<<", ";}}return os << "]";}
template<class S,class T>ostream &operator<<(ostream &os,const map<S,T>&p){os<<"[";for(auto&it:p)os<<it<<" ";return os<<"]";}
template<class T>void dbs(string str,T t){cout<<str<<":"<<t<<"\n";}
template<class T,class...S>void dbs(string str,T t,S... s){int idx=str.find(',');cout<<str.substr(0,idx)<<":"<<t<<",";dbs(str.substr(idx+1),s...);}
template<class T>ostream &operator<<(ostream &os, const deque<T>&d){os<<"[";for(auto&it:d) os << it << " ";return os<<"]";}
#endif
// Debugging Template ends
#define f                       first
#define s                       second
#define ARRAY_INPUT(arr, n)     for(int i = 0; i < n; i++) cin >> arr[i]
#define FORM(i, j, k, inc)      for(int i=j ; i<k ; i+=inc)
#define FOR(i,x)                for(int i = 0; i < x;i++)
#define mip(x)                  ll x;cin>>x
#define ip(x)                   cin>>x
#define pb                      push_back

const int mod = 1e9+7;

using ll = long long;
using pii = pair<int,int>;
using pll = pair<ll,ll>;

using vi = vector<int>;
using vll = vector<long long>;
using vpii = vector<pii>;
using vpll = vector<pll>;

using vvi = vector<vector<int>>;
using vvll = vector<vector<long long>>;
using vvpii = vector<vector<pii>>;
using vvpll = vector<vector<pll>>;

/*
    Generate All Subsets of a given arr (Duplicate Elements)

    Backtracking approach -
    1. Take/Not Take : Just like forming simple subsets
    2. Filling up Slots: Like Permutation

    in 1st approach: 
    Consider [1,2,2]: We will get duplicate subsets
    like [1,2] where 2 can be chosen from any one
    of the two.

    This can be simply mitigated by using
    1. Sorting the array (So the subsets formed are
    all already in sorted manner). If we do not sort
    before hand, we will have to sort when inserting
    as [1,2,2] and [2,1,2] are all same but will be
    counted 
    2. Set for storing: To handle duplicate

    TC: O(2^n * log(2^n))
    SC: O(2^n)


    2. Second approach: 

    Just like in permutation: We had a frequency map
    And at each level, we could have taken any element
    from the map provided it passes a check function
    What this allows is that for duplicate items
    at any level, only one element of it will be taken

    But unlike permutations, where we had multiple choices
    to take and for each choice - we had only one move
    To always take

    Here, we have 2 moves for a single choice
    What this does is create needlessly more same subsets
    in different order.

    In essence at each level, the average number of
    transitions can be size of the map

    To mitigate, we cannot just sort the temp as
    we also do a temp.pop_back() which would mean after
    sorting the wrong element is taken out. Instead
    we have to create another temp arr `T`, sort it
    and then push into a set

*/


int n;
vi arr = {2,3};
// vi ans;
vi temp;


map<int,int> mp;
set<vector<int>> ans;

void second_approach(int level){

    if(level == n) {
        vector<int> t(temp.begin(),temp.end());
        sort(t.begin(),t.end());
        ans.insert(t);
        return;
    }
    // Choices:

    // Not take
    second_approach(level+1);

    // Take
    for(auto &x:mp){
        if(x.second==0)continue;
        temp.pb(x.first);
        x.second--;
        second_approach(level+1);
        temp.pop_back();
        x.second++;
    }
}

void first_approach(int level,vector<int>& arr){

    if(level == n) {
        ans.insert(temp);
        return;
    }
    // Choices:
    // Not take
    first_approach(level+1,arr);

    // Take
    temp.pb(arr[level]);
    first_approach(level+1,arr);
    temp.pop_back();

}

/*

    Note: In all of these approaches, we need a set
    and in Leetcode we need to return vvi not set<vi>
    Thus, another step has to be taken to convert
    set<vi> ans to vvi using
    vvi ANS(ans.begin(),ans.end());

*/

/*

    The intended Approach

    Rather than creating another set<vi> ans, we sort
    of follow a pre-emptive pruning strategy.

    Since in state design we only have a level, we 
    need to change the transition or (M)ove

    In [1,2,2] when we have 1 - T, we have choices
    of both 2, but choosing them at a level would
    lead to same subset, so to prune them, if at
    a level, we have taken the element, we keep track of
    it and if it is duplicate, we skip else we take

    This sort of approach is mixture between the 
    1st and 2nd approach

    We use T/NT with level still indicate arr[level]
    but also in a filling up slot transition

    In a way, at each transition we are incrementing
    the size of the subset form: from 1 size subset
    to 2 -> 3 and so on.
*/

vector<vector<int>> ANS;
vector<int> temp;
int n;
void rec(int level,vector<int>& arr){

    if(level == n) {
        ANS.pb(temp);
        return;
    }
    
    ANS.pb(temp);
    // This is required as at each level, we make
    // incremental sized arr which would not be in ANS
    // if we don't pb here


    for(int i = level; i<n;i++){
        if(i == level || arr[i] != arr[i-1]){
            temp.pb(arr[i]);
            rec(i+1,arr);
            temp.pop_back();
        }
    }
}
void solve(){      
    n = arr.size();
    rec(0,arr);

    for(auto x:ANS){
        pr(x);
    }

}

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr); cout.tie(nullptr);

#ifndef ONLINE_JUDGE
    freopen("Input.txt","r",stdin);
    freopen("Output.txt","w",stdout);
    freopen("Error.txt","w",stderr);
    clock_t tStart = clock();
    cout<<fixed<<setprecision(10)<<"Time Taken: "<<(double)(clock()- tStart)/CLOCKS_PER_SEC<<endl;
#endif


    int t = 1;
    // cin >> t;
    while(t--){
        solve();
    }
}
