#include<bits/stdc++.h>
using namespace std;

// Simple Debugging Template
#ifndef ONLINE_JUDGE
#define pr_arr(a,n)cout<<#a<<":";for(int i=0;i<n;i++)cout<<a[i]<<" ";cout<<endl;
#define pr_mat(mat,row,col)cout<<#mat<<":\n";for(int i=0;i<row;i++){for(int j=0;j<col;j++)cout<<mat[i][j]<<" ";cout<<endl;}
#define pr(...)dbs(#__VA_ARGS__,__VA_ARGS__)
template<class S,class T>ostream &operator<<(ostream &os,const pair<S,T> &p){return os<<"("<<p.first<<","<<p.second<<")";}
template<class T>ostream &operator<<(ostream &os,const vector<T> &p){os<<"[";for(auto&it:p)os<<it<<" ";return os<<"]";}
template<class T>ostream &operator<<(ostream &os,const set<T>&p){os<<"[";for(auto&it:p)os<<it<<" ";return os<<"]";}
template<class T>ostream &operator<<(ostream &os, const stack<T>&s){os<<"[";stack<T> temp(s);while (!temp.empty()){os << temp.top();temp.pop();if (!temp.empty())os << ", ";}return os << "]";}
template<class T>ostream &operator<<(ostream &os, const queue<T>&q){os<<"[";queue<T>temp(q);int size=temp.size();for(int i=0;i<size;i++){T front=temp.front();os<<front;temp.pop();if(i<size-1)os<< ", ";temp.push(front);}return os<< "]";}
template<class T>ostream &operator<<(ostream &os,const multiset<T>&p){os<<"[";for(auto&it:p)os<<it<<" ";return os<<"]";}
template<class T> ostream &operator<<(ostream &os, const priority_queue<T>&pq){os<<"[";priority_queue<T> temp(pq);while(!temp.empty()){os<<temp.top();temp.pop();if(!temp.empty()){os<<", ";}}return os << "]";}
template<class S,class T>ostream &operator<<(ostream &os,const map<S,T>&p){os<<"[";for(auto&it:p)os<<it<<" ";return os<<"]";}
template<class T>void dbs(string str,T t){cout<<str<<":"<<t<<"\n";}
template<class T,class...S>void dbs(string str,T t,S... s){int idx=str.find(',');cout<<str.substr(0,idx)<<":"<<t<<",";dbs(str.substr(idx+1),s...);}
template<class T>ostream &operator<<(ostream &os, const deque<T>&d){os<<"[";for(auto&it:d) os << it << " ";return os<<"]";}
#endif
// Debugging Template ends
#define f                       first
#define s                       second
#define ARRAY_INPUT(arr, n)     for(int i = 0; i < n; i++) cin >> arr[i]
#define FORM(i, j, k, inc)      for(int i=j ; i<k ; i+=inc)
#define FOR(i,x)                for(int i = 0; i < x;i++)
#define mip(x)                  ll x;cin>>x
#define ip(x)                   cin>>x
#define pb                      push_back

const int mod = 1e9+7;

using ll = long long;
using pii = pair<int,int>;
using pll = pair<ll,ll>;

using vi = vector<int>;
using vll = vector<long long>;
using vpii = vector<pii>;
using vpll = vector<pll>;

using vvi = vector<vector<int>>;
using vvll = vector<vector<long long>>;
using vvpii = vector<vector<pii>>;
using vvpll = vector<vector<pll>>;

/*
    Generate All Subsets with Sum equal to Target K
    of a given arr (Both Distinct + Duplicate Elements)

    For Distinct: 
    Simple T/NT idea with LCCM of forming a subset
    In state design: Carry a sum
*/


int n;
vi arr = {2,3,6,7};

vector<vector<int>> ans;
vector<int> temp;
int k;
int n;

void rec(int level, int sum,vector<int>&arr){
    // pruning
    if(sum > k) return;
    
    // basecase
    if(level == n){
        if(sum == k){
            ans.pb(temp);
        }
        return;
    }

//  Choice 1: Don't Take
    rec(level+1,sum,arr);

//  Choice 2: Take
    temp.pb(arr[level]);
    
    rec(level+1,sum+arr[level],arr);
//  rec(level,sum+arr[level],arr) -> If we can take
//  an element unlimited times

    temp.pop_back();
}

/*

    With Duplicates:

    Again 2 approaches

    1. Store in a set. Possible TC
    Is similar to T/NT. Can lead to same subsets
    i.e. same sub tree
    eg [1 2 2 5 6 7 8]
    Choosing first 2 and second 2 individually
    in essence just leads to same tree and same ans

    
    2. We can prune this using the mixed idea I gave
    earlier of T/NT with Filling up slots

    This allows us to not take the duplicate item 
    easily

    Note sorting is important as without sorting, we cannot
    prevent duplicate elements from being taken

    [1 10 1 2] -> Pick 1, then 10, then choice is one 1

    Need to keep track on the elements being chosen at
    a level which cannot be done using a state design
    nor in transition
*/

vector<int> temp;
vector<vector<int>> ans;

void rec(int level, int left, vector<int>&arr){
    // pruning
    if(left == 0){
        ans.push_back(temp);
        return;
    }

    for(int i = level; i < n; i++){
        if(i==level && left-arr[i]>=0 || left - arr[i] >= 0 && arr[i]!=arr[i-1]){
            temp.push_back(arr[i]);
            rec(i+1,left-arr[i],arr);
            temp.pop_back();
        }
    }

}


vector<vector<int>> ANS;
vector<int> temp;
int n;
void rec(int level,vector<int>& arr){

    if(level == n) {
        ANS.pb(temp);
        return;
    }
    
    ANS.pb(temp);
    // This is required as at each level, we make
    // incremental sized arr which would not be in ANS
    // if we don't pb here


    for(int i = level; i<n;i++){
        if(i == level || arr[i] != arr[i-1]){
            temp.pb(arr[i]);
            rec(i+1,arr);
            temp.pop_back();
        }
    }
}
void solve(){      
    n = arr.size();
    k = 7;
    rec(0,arr);

    for(auto x:ANS){
        pr(x);
    }

}

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr); cout.tie(nullptr);

#ifndef ONLINE_JUDGE
    freopen("Input.txt","r",stdin);
    freopen("Output.txt","w",stdout);
    freopen("Error.txt","w",stderr);
    clock_t tStart = clock();
    cout<<fixed<<setprecision(10)<<"Time Taken: "<<(double)(clock()- tStart)/CLOCKS_PER_SEC<<endl;
#endif


    int t = 1;
    // cin >> t;
    while(t--){
        solve();
    }
}
