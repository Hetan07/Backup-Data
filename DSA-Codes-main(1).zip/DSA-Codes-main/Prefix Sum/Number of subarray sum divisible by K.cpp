#include<bits/stdc++.h>
using namespace std;

// Simple Debugging Template
#ifndef ONLINE_JUDGE
#define pr_arr(a,n)cout<<#a<<":";for(int i=0;i<n;i++)cout<<a[i]<<" ";cout<<endl;
#define pr_mat(mat,row,col)cout<<#mat<<":\n";for(int i=0;i<row;i++){for(int j=0;j<col;j++)cout<<mat[i][j]<<" ";cout<<endl;}
#define pr(...)dbs(#__VA_ARGS__,__VA_ARGS__)
template<class S,class T>ostream &operator<<(ostream &os,const pair<S,T> &p){return os<<"("<<p.first<<","<<p.second<<")";}
template<class T>ostream &operator<<(ostream &os,const vector<T> &p){os<<"[";for(auto&it:p)os<<it<<" ";return os<<"]";}
template<class T>ostream &operator<<(ostream &os,const set<T>&p){os<<"[";for(auto&it:p)os<<it<<" ";return os<<"]";}
template<class T>ostream &operator<<(ostream &os, const stack<T>&s){os<<"[";stack<T> temp(s);while (!temp.empty()){os << temp.top();temp.pop();if (!temp.empty())os << ", ";}return os << "]";}
template<class T>ostream &operator<<(ostream &os, const queue<T>&q){os<<"[";queue<T>temp(q);int size=temp.size();for(int i=0;i<size;i++){T front=temp.front();os<<front;temp.pop();if(i<size-1)os<< ", ";temp.push(front);}return os<< "]";}
template<class T>ostream &operator<<(ostream &os,const multiset<T>&p){os<<"[";for(auto&it:p)os<<it<<" ";return os<<"]";}
template<class T> ostream &operator<<(ostream &os, const priority_queue<T>&pq){os<<"[";priority_queue<T> temp(pq);while(!temp.empty()){os<<temp.top();temp.pop();if(!temp.empty()){os<<", ";}}return os << "]";}
template<class S,class T>ostream &operator<<(ostream &os,const map<S,T>&p){os<<"[";for(auto&it:p)os<<it<<" ";return os<<"]";}
template<class T>void dbs(string str,T t){cout<<str<<":"<<t<<"\n";}
template<class T,class...S>void dbs(string str,T t,S... s){int idx=str.find(',');cout<<str.substr(0,idx)<<":"<<t<<",";dbs(str.substr(idx+1),s...);}
template<class T>ostream &operator<<(ostream &os, const deque<T>&d){os<<"[";for(auto&it:d) os << it << " ";return os<<"]";}

#else
#define pr(...){}
#define debarr(a,n){}
#define debmat(mat,row,col){}
#endif
// Debugging Template ends
#define f                       first
#define s                       second
#define ARRAY_INPUT(arr, n)     for(int i = 0; i < n; i++) cin >> arr[i]
#define FORM(i, j, k, inc)       for(int i=j ; i<k ; i+=inc)
#define FOR(i,x)                for(int i = 0; i < x;i++)
#define mip(x)                  ll x;cin>>x
#define ip(x)                   cin>>x
#define pb                      push_back

using ll = long long;
using pii = pair<int,int>;
using pll = pair<ll,ll>;

using vi = vector<int>;
using vll = vector<long long>;
using vpii = vector<pii>;
using vpll = vector<pll>;

using vvi = vector<vector<int>>;
using vvll = vector<vector<long long>>;
using vvpii = vector<vector<pii>>;
using vvpll = vector<vector<pll>>;

using state = pll;

ll n;
ll x;
vll arr;

void solve1(){
    // This is the code to just count the number of subarrs
    ip(n);ip(x); // x is the divisor
    arr.resize(n);
	ARRAY_INPUT(arr,n);
    vll p(n,0); // Here a frequency array is used
	ll pref = 0; // Current Prefix Sum: Acts as P[R]
    ll ans = 0;
    p[pref]++; // Case of Continuous subarray where L = -1
    FOR(i,n){
        pref+=arr[i];
        p[((pref%x)+x)%x]++;
            
    }
    pr(p);
    for(auto a: p){
    	ans += (a*(a-1))/2;
    }
    cout << ans << "\n";
}


void solve(){
    // This is the code to Print Out the subarrs
    ip(n);
	ip(x);
	arr.resize(n);
	ARRAY_INPUT(arr,n);

	// vll p(n,0); 
	vector<set<int>> p; // Here the frequency array has been shifted to a set where we store the indices; 
    // which act like the starting of the subarr
	p.resize(x);
	ll pref = 0;
	vvll all_ans;
	p[pref].insert(-1); // The base case: To have L = -1, means P[L-1] has no contribution and is 0
	
    FOR(i,n){
		pref+=arr[i];
		// This code lists out all the subarrays too
		for(auto x: p[((pref%x)+x)%x]){
			// x represents the L-1 index
			vll temp;
			for(int st = x+1; st<=i;st++) temp.pb(arr[st]);
			all_ans.pb(temp);
		}
		p[((pref%x)+x)%x].insert(i);
		
	}
	pr(all_ans);
}

void solve2(){
    // For maximum or minimum length subarr
    ip(n);
	ip(x);
	arr.resize(n);
	ARRAY_INPUT(arr,n);

	// vll p(n,0); 
	vector<set<int>> p; // Here the frequency array has been shifted to a set where we store the indices; 
    // which act like the starting of the subarr
	p.resize(x);
	ll pref = 0;
	vvll all_ans;
	p[pref].insert(-1); // The base case: To have L = -1, means P[L-1] has no contribution and is 0
	int ans = 1e8;
    FOR(i,n){
		pref+=arr[i];
		// This code lists out all the subarrays too
        if(!p[((pref%x)+x)%x].empty()){
			pr(*p[((pref%x)+x)%x].rbegin());
			ans = min(ans, i-*p[((pref%x)+x)%x].rbegin());
            // Do a max or min here
        }
		p[((pref%x)+x)%x].insert(i);
		
	}
}

void solve3(){
    // Where we specifically want subarr size greater than sz
    int sz = 2;
    map<ll,int> mp;
    ll pref = 0;
    mp[pref] = -1;
    ll ans = 0;
    for(int i = 0; i < arr.size(); i++){
        pref+=arr[i];
        ll check = (pref%x+x)%x;
        if(mp.find(check) != mp.end()){
            ans = (i-mp[check] );
            if(ans > sz-1); // True case
        }
        else{
            mp[check] = i;
            cout << mp[check] << "\n";
        }
    }
}

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr); cout.tie(nullptr);

#ifndef ONLINE_JUDGE
    freopen("Input.txt","r",stdin);
    freopen("Output.txt","w",stdout);
    freopen("Error.txt","w",stderr);
    clock_t tStart = clock();
    cout<<fixed<<setprecision(10)<<"Time Taken: "<<(double)(clock()- tStart)/CLOCKS_PER_SEC<<endl;
#endif


    int t = 1;
    // cin >> t;
    while(t--){
        solve();
    }
}